# Responsive-Resume-UI-Design
How to create the Responsive Resume Design in HTML and CSS
